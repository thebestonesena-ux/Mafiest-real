import Menu from "../components/Menu";
const SobreNosotros = () => (
  <div>
      <Menu />
            <h1 className="title">INFORMACIÓN</h1>
            <ul>
                       <p>
               <li className="popni"> Bienvenidos a TECNO SPACE un luagar donde los niños y jovenes verean como la programación crea la comodidad y la diversión</li>
            </p>
            </ul>
            <p>
                <li className="popni">Nos enfocamos en que cada estudiante logre mejorar grandes habilidades, como pueden ser:</li>
                           <ul>
                <li className="popni">El pensamiento logico</li>
                <li className="popni">Una mayor perseverancia</li>
                <li className="popni">Un mejor manejo en la tecnología</li>
            </ul>
            
            </p>
            <br></br>
            <p className="popni">
             Con nuestro acompañamiento, los niños podrán crear sus propios proyectos y descubrir lo emocionante que es programar. 
            </p>
            <br></br>
            <p className="popni">
              ¡Queremos que se sientan motivados y seguros para enfrentar los retos del mundo digital!
            </p>
  </div>
);

export default SobreNosotros;